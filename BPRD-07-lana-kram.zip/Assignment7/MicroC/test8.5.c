void main(int n)
{
    test(n);
}

void test(int n)
{
    (1 == 1 ? n : 0);
}