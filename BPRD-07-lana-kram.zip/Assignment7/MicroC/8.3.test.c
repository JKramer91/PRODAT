void main(int n)
{
    test(n);
}

void test(int n)
{
    int i;
    i = n; 
    ++i;
    print i;
}

