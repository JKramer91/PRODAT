Our answers can be found in Assignment2/AnswersAssignment2.md 

We also have the generated code from the lexer inside Assignment2/HelloLex. 
Here we have created separate folders for Hello1, Hello2 and Hello3 inside of this folder. 

The code with sinstrtoint and so on can be found in Assignment2/ex2__4Handout.fs 